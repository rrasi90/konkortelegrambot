import React, { useState } from 'react';
import {
  KnowledgeNode,
  NodeDependency,
  InteractiveLesson,
  CoverageStatus,
  QuestionItem,
} from '../data/konkorData';
import {
  LearnerSixDState,
  ROINodeRanking,
  MultiYearFrequencyInsight,
  classifyNodeCourseCategory,
} from '../engine/aelEngine';
import { tmaHaptic } from '../utils/telegramBridge';
import {
  Target,
  BookOpen,
  Play,
  Layers,
  Activity,
  Clock,
  TrendingUp,
  Flame,
  Lock,
  CheckCircle2,
  AlertTriangle,
  Zap,
} from 'lucide-react';

interface SkillTreeGraphProps {
  nodes: KnowledgeNode[];
  dependencies: NodeDependency[];
  questions?: QuestionItem[];
  lessons: Record<string, InteractiveLesson>;
  nodeStates: Record<string, LearnerSixDState>;
  roiRankings: ROINodeRanking[];
  examFrequencyMap: Record<string, MultiYearFrequencyInsight>;
  onStartPracticeNode: (nodeId: string, mode: 'practice' | 'proof' | 'remedial') => void;
  onOpenLessonNode: (nodeId: string) => void;
}

const LAYER_TITLES = [
  'لایه ۰: مبانی و پیش‌نیازهای بنیادی (نقطه شروع داوطلب صفر)',
  'لایه ۱: چارچوب‌های تحلیلی و اقتضایی',
  'لایه ۲: استراتژی، مدل‌سازی و برند',
  'لایه ۳: مرز دانش و مباحث تلفیقی دکتری',
];

const STATUS_META: Record<
  CoverageStatus,
  { label: string; ringClass: string; badgeTextClass: string; shortStatus: string }
> = {
  mastered: {
    label: 'تثبیت‌شده (Mastered)',
    ringClass: 'stroke-emerald-500 dark:stroke-emerald-400',
    badgeTextClass: 'text-emerald-700 dark:text-emerald-300',
    shortStatus: 'تثبیت‌شده',
  },
  proven: {
    label: 'اثبات‌شده با کنکور ۱۴۰۴',
    ringClass: 'stroke-teal-500 dark:stroke-teal-400',
    badgeTextClass: 'text-teal-700 dark:text-teal-300',
    shortStatus: 'اثبات‌شده ۱۴۰۴',
  },
  needs_proof: {
    label: 'آماده اثبات تسلط (Holdout)',
    ringClass: 'stroke-amber-500 dark:stroke-amber-400',
    badgeTextClass: 'text-amber-700 dark:text-amber-300',
    shortStatus: 'آماده اثبات ۱۴۰۴',
  },
  learning: {
    label: 'در حال یادگیری و جمع‌آوری شاهد',
    ringClass: 'stroke-blue-500 dark:stroke-blue-400',
    badgeTextClass: 'text-blue-700 dark:text-blue-300',
    shortStatus: 'در حال یادگیری',
  },
  weak: {
    label: 'نیازمند ترمیم شکاف (Gap)',
    ringClass: 'stroke-rose-500 dark:stroke-rose-400',
    badgeTextClass: 'text-rose-700 dark:text-rose-300',
    shortStatus: 'نیازمند ترمیم',
  },
  unseen: {
    label: 'شروع‌نشده (۰٪ — آماده مطالعه درسنامه)',
    ringClass: 'stroke-slate-400 dark:stroke-slate-600',
    badgeTextClass: 'text-slate-600 dark:text-slate-400',
    shortStatus: 'شروع‌نشده (۰٪)',
  },
};

export const SkillTreeGraph: React.FC<SkillTreeGraphProps> = ({
  nodes,
  dependencies,
  questions = [],
  nodeStates,
  roiRankings,
  examFrequencyMap,
  onStartPracticeNode,
  onOpenLessonNode,
}) => {
  const [selectedNodeId, setSelectedNodeId] = useState<string>('mb.structure');
  const [relationFilter, setRelationFilter] = useState<
    'all' | 'prerequisite' | 'cross_course'
  >('all');
  const [categoryFilter, setCategoryFilter] = useState<
    'all' | 'business' | 'industrial' | 'technology' | 'quantitative' | 'conceptual'
  >('all');

  const nodeQuestionCount = (nodeId: string) =>
    questions.filter((q) => q.nodeId === nodeId).length;

  const matchesCategoryFilter = (n: KnowledgeNode) => {
    if (categoryFilter === 'all') return true;
    if (categoryFilter === 'business') {
      return n.track === 'business' || n.track === 'common' || n.track === 'strategy';
    }
    if (categoryFilter === 'industrial') {
      return (
        n.id.startsWith('ind.') ||
        n.track === 'common' ||
        n.id.startsWith('bus.econ') ||
        n.id.startsWith('bus.math') ||
        n.id.startsWith('bus.islamic') ||
        n.id.startsWith('bus.english')
      );
    }
    if (categoryFilter === 'technology') {
      return (
        n.track === 'technology' ||
        n.track === 'common' ||
        n.id.startsWith('ind.pom') ||
        n.id.startsWith('ind.or')
      );
    }
    if (categoryFilter === 'quantitative') {
      return classifyNodeCourseCategory(n) === 'quantitative';
    }
    if (categoryFilter === 'conceptual') {
      return classifyNodeCourseCategory(n) === 'conceptual';
    }
    return true;
  };

  const getSafeState = (nodeId: string): LearnerSixDState =>
    nodeStates[nodeId] || {
      nodeId,
      masteryScore: 0,
      proficiencyProbability: 0,
      memoryStability: 0,
      retrievability: 0,
      speedFluency: 0,
      coverageStatus: 'unseen',
      evidenceCount: 0,
      isUnlockedInFrontier: true,
      hasLeechCard: false,
      rippleAlert: null,
    };

  const selectedNode = nodes.find((n) => n.id === selectedNodeId) ?? nodes[0];
  const selectedState = getSafeState(selectedNode.id);
  const selectedRoi = roiRankings.find((r) => r.node.id === selectedNode.id);
  const selectedFreq = examFrequencyMap[selectedNode.id];

  // محاسبه پویا عرض بوم SVG تا گره‌های جدید افزوده‌شده توسط ایجنت هیچ‌گاه از کادر بیرون نزنند
  const maxColIndex = Math.max(3, ...nodes.map((n) => n.graphPos.col));
  const svgWidth = Math.max(1000, 150 + maxColIndex * 235 + 150);

  const getCoords = (node: KnowledgeNode) => {
    const x = 130 + node.graphPos.col * 235;
    const y = 75 + node.graphPos.layer * 145;
    return { x, y };
  };

  const nodeMap = new Map<string, KnowledgeNode>(nodes.map((n) => [n.id, n]));

  const incomingEdges = dependencies.filter((d) => d.source === selectedNode.id);
  const outgoingEdges = dependencies.filter((d) => d.target === selectedNode.id);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* بوم گراف تعاملی درخت مهارت (8 ستون) */}
      <div className="lg:col-span-8 bg-white/95 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/80 dark:border-slate-800/80 rounded-2xl p-5 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 mb-4 border-b border-slate-200/70 dark:border-slate-800/80">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
              درخت مهارت، مرز دانش (Knowledge Frontier) و رادار کنکور ({nodes.length} گره)
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              طبق الگوریتم MathAcademy FIRe، حل تست مباحث بالاتر به‌طور خودکار به پیش‌نیازهای متصل اعتبار مرور کسری می‌دهد.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {[
              { id: 'all', label: `همه (${nodes.length})` },
              { id: 'business', label: 'بازرگانی' },
              { id: 'industrial', label: 'صنعتی' },
              { id: 'technology', label: 'فناوری' },
              { id: 'quantitative', label: 'کمی و محاسباتی' },
              { id: 'conceptual', label: 'مفهومی و تئوری' },
            ].map((cf) => (
              <button
                key={cf.id}
                type="button"
                onClick={() => {
                  tmaHaptic.selection();
                  setCategoryFilter(cf.id as any);
                }}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors duration-200 cursor-pointer ${
                  categoryFilter === cf.id
                    ? 'bg-blue-600 text-white font-bold shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {cf.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800/90 rounded-xl">
            <button
              type="button"
              onClick={() => {
                tmaHaptic.selection();
                setRelationFilter('all');
              }}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors duration-200 whitespace-nowrap shrink-0 cursor-pointer ${
                relationFilter === 'all'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs font-bold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              همه یال‌ها ({dependencies.length})
            </button>
            <button
              type="button"
              onClick={() => {
                tmaHaptic.selection();
                setRelationFilter('prerequisite');
              }}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors duration-200 whitespace-nowrap shrink-0 cursor-pointer ${
                relationFilter === 'prerequisite'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs font-bold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              پیش‌نیاز مستقیم (FIRe)
            </button>
            <button
              type="button"
              onClick={() => {
                tmaHaptic.selection();
                setRelationFilter('cross_course');
              }}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors duration-200 whitespace-nowrap shrink-0 cursor-pointer ${
                relationFilter === 'cross_course'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs font-bold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              پل بین‌درسی
            </button>
          </div>
        </div>

        {/* راهنمای بصری با آیکون‌های SVG خالص (بدون ایموجی طبق استاندارد UI/UX Pro Max) */}
        <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-slate-600 dark:text-slate-400 mb-4">
          <span className="inline-flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5 text-amber-500" />
            <span>فصل فوق‌پرتکرار کنکور (≥۶ سال تکرار)</span>
          </span>
          <span aria-hidden="true">·</span>
          <span className="inline-flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
            <span>سبز: تثبیت/اثبات‌شده</span>
          </span>
          <span aria-hidden="true">·</span>
          <span className="inline-flex items-center gap-1.5">
            <Target className="w-3.5 h-3.5 text-amber-500" />
            <span>کهربایی: آماده اثبات ۱۴۰۴</span>
          </span>
          <span aria-hidden="true">·</span>
          <span className="inline-flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-slate-400" />
            <span>قفل پیش‌نیاز: نیازمند مطالعه لایه پایین‌تر</span>
          </span>
        </div>

        <div className="w-full overflow-x-auto rounded-xl bg-slate-50/70 dark:bg-[#0d1322] border border-slate-200/60 dark:border-slate-800/70 p-2">
          <svg
            viewBox={`0 0 ${svgWidth} 620`}
            className="w-full min-w-[760px] h-auto select-none"
            role="img"
            aria-label="گراف تعاملی درخت مهارت کنکور دکتری"
          >
            <defs>
              <marker
                id="arrow-prereq"
                viewBox="0 0 10 10"
                refX="8"
                refY="5"
                markerWidth="6"
                markerHeight="6"
                orient="auto-start-reverse"
              >
                <path
                  d="M 0 1 L 10 5 L 0 9 z"
                  className="fill-blue-500/70 dark:fill-blue-400/70"
                />
              </marker>
              <marker
                id="arrow-cross"
                viewBox="0 0 10 10"
                refX="8"
                refY="5"
                markerWidth="6"
                markerHeight="6"
                orient="auto-start-reverse"
              >
                <path
                  d="M 0 1 L 10 5 L 0 9 z"
                  className="fill-purple-500/70 dark:fill-purple-400/70"
                />
              </marker>
              <marker
                id="arrow-active"
                viewBox="0 0 10 10"
                refX="8"
                refY="5"
                markerWidth="7"
                markerHeight="7"
                orient="auto-start-reverse"
              >
                <path
                  d="M 0 1 L 10 5 L 0 9 z"
                  className="fill-amber-500 dark:fill-amber-400"
                />
              </marker>
            </defs>

            {[0, 1, 2, 3].map((layerIdx) => {
              const y = 75 + layerIdx * 145;
              return (
                <g key={layerIdx}>
                  <line
                    x1="25"
                    y1={y}
                    x2={svgWidth - 25}
                    y2={y}
                    className="stroke-slate-200/70 dark:stroke-slate-800/60"
                    strokeDasharray="4 4"
                    strokeWidth="1"
                  />
                  <text
                    x={svgWidth - 30}
                    y={y - 44}
                    textAnchor="start"
                    className="fill-slate-400 dark:fill-slate-500 text-[11px] font-medium"
                  >
                    {LAYER_TITLES[layerIdx]}
                  </text>
                </g>
              );
            })}

            {dependencies
              .filter(
                (edge) => relationFilter === 'all' || edge.relation === relationFilter
              )
              .map((edge, idx) => {
                const srcNode = nodeMap.get(edge.source);
                const tgtNode = nodeMap.get(edge.target);
                if (!srcNode || !tgtNode) return null;

                const p1 = getCoords(tgtNode);
                const p2 = getCoords(srcNode);

                const isHighlighted =
                  selectedNodeId === edge.source || selectedNodeId === edge.target;

                const midY = (p1.y + p2.y) / 2;
                const pathD = `M ${p1.x} ${p1.y + 28} C ${p1.x} ${midY}, ${p2.x} ${midY}, ${p2.x} ${p2.y - 32}`;

                return (
                  <g key={`${edge.source}-${edge.target}-${idx}`}>
                    <path
                      d={pathD}
                      fill="none"
                      strokeWidth={isHighlighted ? 2.8 : 1.6}
                      strokeDasharray={
                        edge.relation === 'cross_course' ? '6 4' : undefined
                      }
                      markerEnd={
                        isHighlighted
                          ? 'url(#arrow-active)'
                          : edge.relation === 'cross_course'
                          ? 'url(#arrow-cross)'
                          : 'url(#arrow-prereq)'
                      }
                      className={
                        isHighlighted
                          ? 'stroke-amber-500 dark:stroke-amber-400 transition-all duration-200'
                          : edge.relation === 'cross_course'
                          ? 'stroke-purple-400/50 dark:stroke-purple-500/45'
                          : 'stroke-slate-300 dark:stroke-slate-700'
                      }
                    />
                  </g>
                );
              })}

            {nodes.map((node) => {
              const { x, y } = getCoords(node);
              const st = getSafeState(node.id);
              const freq = examFrequencyMap[node.id];
              const isSelected = selectedNodeId === node.id;
              const inFilter = matchesCategoryFilter(node);
              const isConnected = dependencies.some(
                (d) =>
                  (d.source === selectedNodeId && d.target === node.id) ||
                  (d.target === selectedNodeId && d.source === node.id)
              );

              const meta = STATUS_META[st.coverageStatus] || STATUS_META.unseen;
              const radius = 26;
              const shortTitle =
                node.topic.length > 24 ? node.topic.slice(0, 23) + '…' : node.topic;

              return (
                <g
                  key={node.id}
                  transform={`translate(${x}, ${y})`}
                  onClick={() => {
                    tmaHaptic.selection();
                    setSelectedNodeId(node.id);
                  }}
                  className={`cursor-pointer group transition-opacity duration-200 ${
                    inFilter || isSelected ? 'opacity-100' : 'opacity-25'
                  }`}
                >
                  <rect
                    x="-98"
                    y="-32"
                    width="196"
                    height="68"
                    rx="14"
                    className={`transition-colors duration-200 ${
                      isSelected
                        ? 'fill-blue-50/95 dark:fill-blue-950/80 stroke-blue-500 dark:stroke-blue-400 stroke-2'
                        : isConnected
                        ? 'fill-white dark:fill-slate-800/95 stroke-amber-400/80 dark:stroke-amber-400/70 stroke-[1.5]'
                        : !st.isUnlockedInFrontier
                        ? 'fill-slate-100/80 dark:fill-slate-900/50 stroke-slate-200/70 dark:stroke-slate-800/70 stroke-1 opacity-75'
                        : 'fill-white/95 dark:fill-slate-900/95 stroke-slate-200 dark:stroke-slate-800 stroke-1 group-hover:stroke-slate-400 dark:group-hover:stroke-slate-600'
                    }`}
                  />

                  <g transform="translate(62, 2)">
                    <circle
                      r={radius - 6}
                      className="fill-slate-50 dark:fill-slate-950 stroke-slate-200 dark:stroke-slate-800"
                      strokeWidth="4"
                    />
                    <circle
                      r={radius - 6}
                      fill="none"
                      strokeWidth="4"
                      strokeLinecap="round"
                      strokeDasharray={2 * Math.PI * (radius - 6)}
                      strokeDashoffset={
                        2 * Math.PI * (radius - 6) * (1 - st.masteryScore / 100)
                      }
                      transform="rotate(-90)"
                      className={meta.ringClass}
                    />
                    <text
                      x="0"
                      y="4"
                      textAnchor="middle"
                      className="fill-slate-800 dark:fill-slate-100 text-[11px] font-bold"
                    >
                      {st.masteryScore}٪
                    </text>
                  </g>

                  <text
                    x="32"
                    y="-9"
                    textAnchor="start"
                    className={
                      freq?.isHighYieldCritical
                        ? 'fill-amber-600 dark:fill-amber-400 text-[10px] font-bold'
                        : 'fill-slate-400 dark:fill-slate-400 text-[10px]'
                    }
                  >
                    {freq?.isHighYieldCritical
                      ? `پرتکرار (${freq.appearanceCount} دوره کنکور)`
                      : node.course.slice(0, 20)}
                  </text>
                  <text
                    x="32"
                    y="9"
                    textAnchor="start"
                    className="fill-slate-900 dark:fill-slate-100 text-[11px] font-bold"
                  >
                    {shortTitle}
                  </text>

                  <text
                    x="32"
                    y="25"
                    textAnchor="start"
                    className={`text-[10px] font-medium ${
                      st.hasLeechCard
                        ? 'fill-rose-600 dark:fill-rose-400'
                        : !st.isUnlockedInFrontier
                        ? 'fill-slate-400 dark:fill-slate-500'
                        : st.coverageStatus === 'needs_proof'
                        ? 'fill-amber-600 dark:fill-amber-400'
                        : st.coverageStatus === 'mastered' ||
                          st.coverageStatus === 'proven'
                        ? 'fill-emerald-600 dark:fill-emerald-400'
                        : 'fill-blue-600 dark:fill-blue-400'
                    }`}
                  >
                    {st.hasLeechCard
                      ? 'کارت چغر (نیاز به درسنامه)'
                      : !st.isUnlockedInFrontier
                      ? 'قفل پیش‌نیاز (خارج از مرز دانش)'
                      : `${meta.shortStatus} · ${nodeQuestionCount(node.id)} تست`}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* فهرست کارتی سریع گره‌های فیلترشده در زیر گراف برای دسترسی تک‌کلیکی */}
        <div className="mt-4 pt-4 border-t border-slate-200/70 dark:border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-3">
            <span>
              فهرست سریع مباحث فیلترشده ({nodes.filter(matchesCategoryFilter).length} مبحث از {nodes.length} گره درخت دانشی)
            </span>
            <span>کلیک روی هر کارت = مشاهده جزئیات و شروع درس یا تست</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-2.5 max-h-72 overflow-y-auto pr-1">
            {nodes.filter(matchesCategoryFilter).map((n) => {
              const st = nodeStates[n.id];
              const qCount = nodeQuestionCount(n.id);
              const freq = examFrequencyMap[n.id];
              const isSel = selectedNodeId === n.id;
              return (
                <div
                  key={n.id}
                  onClick={() => setSelectedNodeId(n.id)}
                  className={`p-3 rounded-xl border text-xs transition-all cursor-pointer flex flex-col justify-between gap-2 ${
                    isSel
                      ? 'bg-blue-500/10 border-blue-500 text-slate-900 dark:text-white'
                      : 'bg-slate-50/80 dark:bg-slate-800/40 border-slate-200/80 dark:border-slate-800 hover:border-slate-400'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-1 text-[11px] text-slate-500 dark:text-slate-400">
                      <span className="truncate">{n.course}</span>
                      <span className="font-mono font-bold text-slate-700 dark:text-slate-300 shrink-0 tabular-nums">
                        {st?.masteryScore ?? 0}٪
                      </span>
                    </div>
                    <div className="font-bold text-slate-900 dark:text-white mt-0.5 truncate">
                      {n.topic}
                    </div>
                  </div>
                  <div className="flex items-center justify-between gap-2 pt-1.5 border-t border-slate-200/60 dark:border-slate-700/60 text-[11px]">
                    <span className="text-slate-500 dark:text-slate-400 tabular-nums">
                      {qCount} تست · {freq?.appearanceCount ?? n.examYearsAppeared.length} دوره کنکور
                    </span>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenLessonNode(n.id);
                        }}
                        className="px-2 py-0.5 rounded bg-blue-600/10 hover:bg-blue-600 text-blue-600 hover:text-white dark:text-blue-400 font-bold transition-colors cursor-pointer"
                      >
                        درسنامه
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onStartPracticeNode(n.id, 'practice');
                        }}
                        className="px-2 py-0.5 rounded bg-emerald-600/10 hover:bg-emerald-600 text-emerald-700 hover:text-white dark:text-emerald-400 font-bold transition-colors cursor-pointer"
                      >
                        تست
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* بازرس ۶بعدی گره انتخاب‌شده (Node 6D Inspector) (4 ستون) */}
      <div className="lg:col-span-4 bg-white/95 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/80 dark:border-slate-800/80 rounded-2xl p-5 shadow-xs sticky top-20">
        <div className="flex items-start justify-between gap-3 pb-3 mb-4 border-b border-slate-200/70 dark:border-slate-800/80">
          <div>
            <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <span>{selectedNode.course}</span>
              <span aria-hidden="true">·</span>
              <span>{selectedNode.chapter}</span>
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white mt-1">
              {selectedNode.topic}
            </h3>
          </div>
          <span className="text-xs font-mono text-slate-400 dark:text-slate-500 shrink-0">
            {selectedNode.id}
          </span>
        </div>

        {/* رادار تکرار در کنکور دکتری */}
        {selectedFreq && (
          <div className="mb-4 p-3 rounded-xl bg-amber-500/10 border border-amber-500/25 text-xs space-y-1">
            <div className="font-bold text-amber-800 dark:text-amber-300 flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-amber-500 shrink-0" />
              <span>{selectedFreq.importanceBadge}</span>
            </div>
            <div className="text-[11px] text-slate-700 dark:text-slate-300">
              سال‌های طرح سؤال:{' '}
              <strong className="tabular-nums">
                {selectedFreq.yearsAppeared.join('، ')}
              </strong>
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400">
              منبع: {selectedNode.sourceBookCitation}
            </div>
          </div>
        )}

        <div className="mb-4 flex items-center justify-between text-xs bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60 rounded-xl px-3.5 py-2.5">
          <span className="text-slate-600 dark:text-slate-300 font-medium">
            وضعیت مرز دانش:
          </span>
          <span
            className={`font-bold flex items-center gap-1.5 ${STATUS_META[selectedState.coverageStatus].badgeTextClass}`}
          >
            {!selectedState.isUnlockedInFrontier ? (
              <>
                <Lock className="w-3.5 h-3.5" />
                <span>قفل پیش‌نیاز</span>
              </>
            ) : selectedState.hasLeechCard ? (
              <>
                <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
                <span>کارت چغر (Leech)</span>
              </>
            ) : selectedState.rippleAlert === 'probe_queued' ? (
              <>
                <Zap className="w-3.5 h-3.5 text-amber-500" />
                <span>تست تشخیصی در صف</span>
              </>
            ) : (
              <span>{STATUS_META[selectedState.coverageStatus].label}</span>
            )}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-5">
          <div className="p-3 rounded-xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/50 dark:border-slate-800">
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
              <span>۱. احتمال تسلط مفهومی</span>
              <Activity className="w-3.5 h-3.5 text-blue-500" />
            </div>
            <div className="text-lg font-bold text-slate-900 dark:text-white mt-1 tabular-nums">
              {selectedState.masteryScore}٪
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
              امتیاز درسنامه:{' '}
              {selectedState.lastLessonSelfRating
                ? `${selectedState.lastLessonSelfRating} از ۵`
                : 'ثبت‌نشده'}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/50 dark:border-slate-800">
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
              <span>۲. پایداری حافظه FSRS</span>
              <Clock className="w-3.5 h-3.5 text-emerald-500" />
            </div>
            <div className="text-lg font-bold text-slate-900 dark:text-white mt-1 tabular-nums">
              {selectedState.memoryStability} روز
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
              بازیابی فعلی: {Math.round(selectedState.retrievability * 100)}٪
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/50 dark:border-slate-800">
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
              <span>۳. بازده سرمایه‌گذاری (ROI)</span>
              <TrendingUp className="w-3.5 h-3.5 text-amber-500" />
            </div>
            <div className="text-lg font-bold text-slate-900 dark:text-white mt-1 tabular-nums">
              {selectedRoi?.roiScore ?? 75} از ۱۰۰
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
              ضریب کنکور: {selectedNode.examCoefficient} (تخصصی)
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/50 dark:border-slate-800">
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
              <span>۴. شواهد و سرعت</span>
              <Layers className="w-3.5 h-3.5 text-purple-500" />
            </div>
            <div className="text-lg font-bold text-slate-900 dark:text-white mt-1 tabular-nums">
              {selectedState.evidenceCount} شاهد
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
              روانی پاسخ: {selectedState.speedFluency}٪
            </div>
          </div>
        </div>

        <div className="space-y-3 mb-5 text-xs">
          <div>
            <h4 className="font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              پیش‌نیازهای مستقیم (دریافت‌کننده اعتبار FIRe از این مبحث):
            </h4>
            {incomingEdges.length === 0 ? (
              <p className="text-slate-500 dark:text-slate-400">
                این گره جزو مباحث پایه (لایه ۰) است و پیش‌نیاز قبلی ندارد.
              </p>
            ) : (
              <div className="space-y-1.5">
                {incomingEdges.map((e) => {
                  const target = nodeMap.get(e.target);
                  if (!target) return null;
                  return (
                    <button
                      key={e.target}
                      type="button"
                      onClick={() => {
                        tmaHaptic.selection();
                        setSelectedNodeId(target.id);
                      }}
                      className="w-full text-right p-2 rounded-lg bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors duration-200 flex items-center justify-between gap-2 cursor-pointer"
                    >
                      <span className="font-medium text-slate-800 dark:text-slate-200 truncate">
                        ← {target.topic}
                      </span>
                      <span className="text-slate-500 dark:text-slate-400 shrink-0 tabular-nums">
                        {nodeStates[target.id]?.masteryScore}٪
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {outgoingEdges.length > 0 && (
            <div>
              <h4 className="font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                مباحث پیشرفته‌ای که پس از تسلط بر این گره باز می‌شوند:
              </h4>
              <div className="space-y-1.5">
                {outgoingEdges.map((e) => {
                  const dep = nodeMap.get(e.source);
                  if (!dep) return null;
                  return (
                    <button
                      key={e.source}
                      type="button"
                      onClick={() => {
                        tmaHaptic.selection();
                        setSelectedNodeId(dep.id);
                      }}
                      className="w-full text-right p-2 rounded-lg bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors duration-200 flex items-center justify-between gap-2 cursor-pointer"
                    >
                      <span className="font-medium text-slate-800 dark:text-slate-200 truncate">
                        ↳ {dep.topic}
                      </span>
                      <span className="text-slate-500 dark:text-slate-400 shrink-0 tabular-nums">
                        {nodeStates[dep.id]?.masteryScore}٪
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* دکمه‌های عملیاتی روی گره */}
        <div className="space-y-2.5 pt-3 border-t border-slate-200/70 dark:border-slate-800">
          <button
            type="button"
            onClick={() => {
              tmaHaptic.impact('light');
              onOpenLessonNode(selectedNode.id);
            }}
            className="min-h-[42px] w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors duration-200 shadow-xs cursor-pointer"
          >
            <BookOpen className="w-4 h-4" />
            <span>۱. مطالعه درسنامه گام‌به‌گام و ثبت امتیاز ۱ تا ۵</span>
          </button>

          {selectedState.coverageStatus === 'needs_proof' ? (
            <button
              type="button"
              onClick={() => {
                tmaHaptic.impact('heavy');
                onStartPracticeNode(selectedNode.id, 'proof');
              }}
              className="min-h-[42px] w-full py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-colors duration-200 shadow-xs cursor-pointer"
            >
              <Target className="w-4 h-4" />
              <span>۲. شروع تست قرنطینه ۱۴۰۴ (اثبات تسلط)</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                tmaHaptic.impact('medium');
                onStartPracticeNode(selectedNode.id, 'practice');
              }}
              className="min-h-[42px] w-full py-2.5 px-4 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors duration-200 cursor-pointer"
            >
              <Play className="w-4 h-4 text-blue-500" />
              <span>۲. حل تست‌های استاندارد این مبحث</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
