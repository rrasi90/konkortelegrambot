import React, { useState } from 'react';
import { KnowledgeNode, TRACK_LABELS, TrackId } from '../data/konkorData';
import { YEARLY_KONKOR_BOOKLETS } from '../data/yearlyKonkorExams';
import {
  LearnerSixDState,
  ReviewCard,
  UserStats,
  ROINodeRanking,
  MultiYearFrequencyInsight,
  StudyCourseCategory,
  MajorExamBranch,
} from '../engine/aelEngine';
import { shareProgressToTelegramChat, tmaHaptic } from '../utils/telegramBridge';
import {
  Play,
  Target,
  Moon,
  Flame,
  TrendingUp,
  Compass,
  BookOpen,
  ArrowLeft,
  RotateCcw,
  CheckCircle2,
  AlertOctagon,
  Award,
  Share2,
  Bot,
  SlidersHorizontal,
  GraduationCap,
} from 'lucide-react';

interface DashboardViewProps {
  nodes: KnowledgeNode[];
  stats: UserStats;
  nodeStates: Record<string, LearnerSixDState>;
  queue: ReviewCard[];
  roiRankings: ROINodeRanking[];
  examFrequencyList: MultiYearFrequencyInsight[];
  onStartDailySession: () => void;
  onStartNightQuiz: () => void;
  onOpenPlacementModal: () => void;
  onOpenTelegramBotSimulator: () => void;
  onChangeStudyMode: (mode: 'desk' | 'commute' | 'quick') => void;
  onUpdateStudyPreferences: (prefs: {
    dailyStudyHours?: number;
    dailyTargetQuestions?: number;
    preferredCourseCategory?: StudyCourseCategory;
    selectedMajorBranch?: MajorExamBranch;
  }) => void;
  onToggleTrack: (track: TrackId) => void;
  onUseStreakFreeze: () => void;
  onStartPracticeNode: (nodeId: string, mode: 'practice' | 'proof' | 'remedial') => void;
  onOpenLessonNode: (nodeId: string) => void;
  onOpenYearlyExam: (year?: number) => void;
  onNavigateTab: (tab: 'study' | 'exams' | 'map' | 'lessons' | 'ingest' | 'patches') => void;
  onResetToZeroState: () => void;
}

const BRANCH_LABELS: Record<MajorExamBranch, string> = {
  business: 'مدیریت بازرگانی',
  industrial: 'مدیریت صنعتی',
  technology: 'مدیریت تکنولوژی',
  phd_all: 'دکتری تخصصی مدیریت',
};

const CATEGORY_LABELS: Record<StudyCourseCategory, string> = {
  all: 'ترکیبی همه دروس',
  conceptual: 'دروس مفهومی و تئوری',
  quantitative: 'دروس کمی و محاسباتی',
  language: 'زبان عمومی و تخصصی',
};

export const DashboardView: React.FC<DashboardViewProps> = ({
  nodes,
  stats,
  nodeStates,
  queue,
  roiRankings,
  examFrequencyList,
  onStartDailySession,
  onStartNightQuiz,
  onOpenPlacementModal,
  onOpenTelegramBotSimulator,
  onUpdateStudyPreferences,
  onToggleTrack,
  onStartPracticeNode,
  onOpenLessonNode,
  onOpenYearlyExam,
  onNavigateTab,
  onResetToZeroState,
}) => {
  const [shareToast, setShareToast] = useState<string | null>(null);
  const [showPathConfig, setShowPathConfig] = useState<boolean>(false);

  const allStates = Object.values(nodeStates) as LearnerSixDState[];
  const overallMastery = Math.round(
    allStates.reduce((acc, s) => acc + s.masteryScore, 0) / Math.max(1, allStates.length)
  );
  const masteredOrProvenCount = allStates.filter(
    (s) => s.coverageStatus === 'mastered' || s.coverageStatus === 'proven'
  ).length;
  const needsProofNodes = nodes.filter(
    (n) => nodeStates[n.id]?.coverageStatus === 'needs_proof'
  );
  const leechNodesCount = allStates.filter((s) => s.hasLeechCard).length;
  const probeOrRemedialCards = queue.filter(
    (c) =>
      c.cardType === 'diagnostic_probe' ||
      c.cardType === 'remedial_lesson' ||
      c.cardType === 'comparison_card' ||
      c.cardType === 'trap_note'
  );

  // محاسبه درصد خالص کنکور با فرمول نمره منفی (۳+ درست، ۱- غلط)
  const rawDenominator = Math.max(1, stats.totalAnswered * 3);
  const rawScoreWithNegative = Math.max(0, stats.correctCount * 3 - stats.wrongCount * 1);
  const netKonkorPercent =
    stats.totalAnswered === 0 ? 0 : Math.round((rawScoreWithNegative / rawDenominator) * 100);

  const ringRadius = 44;
  const ringCircumference = 2 * Math.PI * ringRadius;
  const ringOffset = ringCircumference * (1 - overallMastery / 100);

  const topMultiYearNodes = [...examFrequencyList]
    .sort((a, b) => b.appearanceCount - a.appearanceCount)
    .slice(0, 6);

  const activeBranch = stats.selectedMajorBranch || 'business';
  const activeCategory = stats.preferredCourseCategory || 'all';
  const activeHours = stats.dailyStudyHours || 4;
  const activeTargetQ = stats.dailyTargetQuestions || 20;

  const handleShareTelegram = () => {
    shareProgressToTelegramChat({
      overallMastery,
      netKonkorPercent,
      streakDays: stats.streakDays,
      lessonsRatedCount: stats.lessonsRatedCount,
    });
    setShareToast('گزارش پیشرفت کپی شد');
    setTimeout(() => setShareToast(null), 3000);
  };

  return (
    <div className="space-y-6">
      {/* ۱. نوار خلاصه مسیر آموزشی شخصی و وضعیت داوطلب */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800/80 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600 dark:text-slate-400">
          <span className="font-bold text-slate-900 dark:text-white tabular-nums">
            {stats.streakDays} روز پیوسته · {stats.xp} XP
          </span>
          <span aria-hidden="true">·</span>
          <span>
            گرایش: <strong className="text-slate-900 dark:text-white">{BRANCH_LABELS[activeBranch]}</strong>
          </span>
          <span aria-hidden="true">·</span>
          <span className="tabular-nums">
            برنامه روزانه: <strong className="text-slate-900 dark:text-white">{activeHours} ساعت ({activeTargetQ} تست)</strong>
          </span>
          <span aria-hidden="true">·</span>
          <span>{CATEGORY_LABELS[activeCategory]}</span>

          {shareToast && (
            <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{shareToast}</span>
            </span>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setShowPathConfig((prev) => !prev)}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
              showPathConfig
                ? 'bg-blue-600 text-white'
                : 'bg-blue-600/10 hover:bg-blue-600/20 text-blue-700 dark:text-blue-300'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>تنظیم مسیر مطالعه</span>
          </button>

          <button
            type="button"
            onClick={() => {
              tmaHaptic.impact('medium');
              onOpenTelegramBotSimulator();
            }}
            className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Bot className="w-3.5 h-3.5 text-sky-500" />
            <span>ربات تلگرام</span>
          </button>

          <button
            type="button"
            onClick={handleShareTelegram}
            className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Share2 className="w-3.5 h-3.5 text-sky-500" />
            <span>اشتراک کارنامه</span>
          </button>

          {!stats.isZeroStateNewUser && (
            <button
              type="button"
              onClick={() => {
                tmaHaptic.notify('warning');
                onResetToZeroState();
              }}
              className="px-2.5 py-2 rounded-xl text-rose-600 dark:text-rose-400 hover:bg-rose-500/10 text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer"
              title="ریست کامل به صفر"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>ریست</span>
            </button>
          )}
        </div>
      </div>

      {/* پنل بازشونده تنظیم مسیر آموزشی شخصی (۴ پرسش کلیدی) */}
      {showPathConfig && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200/70 dark:border-slate-800">
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                شخصی‌سازی مسیر مطالعه (گرایش، ساعت مطالعه روزانه، نوع دروس و تعداد تست)
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                دروس ضریب صفر گرایش انتخابی شما به صورت خودکار حذف شده و صف مرور امروز بر اساس بودجه زمانی شما چیده می‌شود.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowPathConfig(false)}
              className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
            >
              بستن پنل تنظیمات
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            {/* ۱. انتخاب گرایش */}
            <div className="space-y-2">
              <label className="block font-bold text-slate-800 dark:text-slate-200">
                ۱. گرایش هدف شما در کنکور چیست؟
              </label>
              <div className="grid grid-cols-1 gap-1.5">
                {[
                  { id: 'business', label: 'ارشد مدیریت بازرگانی (بازاریابی ضریب ۴)' },
                  { id: 'industrial', label: 'ارشد مدیریت صنعتی (تحقیق در عملیات ضریب ۳)' },
                  { id: 'technology', label: 'ارشد مدیریت تکنولوژی (تئوری و زبان ضریب ۳)' },
                  { id: 'phd_all', label: 'دکتری تخصصی مدیریت (همه گرایش‌ها)' },
                ].map((b) => {
                  const active = activeBranch === b.id;
                  return (
                    <button
                      key={b.id}
                      type="button"
                      onClick={() => {
                        tmaHaptic.selection();
                        onUpdateStudyPreferences({
                          selectedMajorBranch: b.id as MajorExamBranch,
                        });
                      }}
                      className={`p-2 rounded-xl border text-right transition-all cursor-pointer ${
                        active
                          ? 'bg-blue-600 text-white border-blue-500 font-bold'
                          : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-blue-400'
                      }`}
                    >
                      {b.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* ۲. نوع دروس مورد علاقه */}
            <div className="space-y-2">
              <label className="block font-bold text-slate-800 dark:text-slate-200">
                ۲. چه نوع دروسی را می‌خواهید بخوانید؟
              </label>
              <div className="grid grid-cols-1 gap-1.5">
                {[
                  { id: 'all', label: 'ترکیبی همه دروس (تئوری + کمی + زبان)' },
                  { id: 'conceptual', label: 'دروس مفهومی و حفظی (تئوری، بازاریابی، اسلام)' },
                  { id: 'quantitative', label: 'دروس کمی و محاسباتی (OR، آمار، اقتصاد، تولید)' },
                  { id: 'language', label: 'زبان عمومی و تخصصی انگلیسی (ضریب ۳)' },
                ].map((cat) => {
                  const active = activeCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => {
                        tmaHaptic.selection();
                        onUpdateStudyPreferences({
                          preferredCourseCategory: cat.id as StudyCourseCategory,
                        });
                      }}
                      className={`p-2 rounded-xl border text-right transition-all cursor-pointer ${
                        active
                          ? 'bg-emerald-600 text-white border-emerald-500 font-bold'
                          : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-emerald-400'
                      }`}
                    >
                      {cat.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* ۳. ساعت مطالعه روزانه */}
            <div className="space-y-2">
              <label className="block font-bold text-slate-800 dark:text-slate-200">
                ۳. روزی چند ساعت می‌خواهید درس بخوانید؟
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {[1, 2, 3, 4, 6, 8].map((hrs) => {
                  const active = activeHours === hrs;
                  return (
                    <button
                      key={hrs}
                      type="button"
                      onClick={() => {
                        tmaHaptic.selection();
                        onUpdateStudyPreferences({ dailyStudyHours: hrs });
                      }}
                      className={`py-2 px-2.5 rounded-xl border text-center transition-all cursor-pointer tabular-nums ${
                        active
                          ? 'bg-blue-600 text-white border-blue-500 font-bold'
                          : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-blue-400'
                      }`}
                    >
                      {hrs} ساعت
                    </button>
                  );
                })}
              </div>
            </div>

            {/* ۴. تعداد تست هدف در روز */}
            <div className="space-y-2">
              <label className="block font-bold text-slate-800 dark:text-slate-200">
                ۴. روزی چند تست می‌خواهید بزنید؟
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {[5, 10, 15, 20, 30, 50].map((qTarget) => {
                  const active = activeTargetQ === qTarget;
                  return (
                    <button
                      key={qTarget}
                      type="button"
                      onClick={() => {
                        tmaHaptic.selection();
                        onUpdateStudyPreferences({ dailyTargetQuestions: qTarget });
                      }}
                      className={`py-2 px-2.5 rounded-xl border text-center transition-all cursor-pointer tabular-nums ${
                        active
                          ? 'bg-amber-500 text-slate-950 border-amber-500 font-bold'
                          : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-amber-400'
                      }`}
                    >
                      {qTarget} تست
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ۲. بخش اصلی دو ستونی: شروع مرور تطبیقی امروز (۷ ستون) + وضعیت تسلط و مأموریت‌ها (۵ ستون) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* کارت شروع جلسه امروز */}
        <div className="lg:col-span-7 rounded-2xl p-6 bg-slate-900 dark:bg-slate-900 text-white border border-slate-800 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
              <span>صف هوشمند امروز بر اساس بودجه‌بندی کنکور و منحنی فراموشی FSRS</span>
              <span className="font-mono tabular-nums text-blue-400 font-bold">
                {queue.length} گام آماده در صف امروز
              </span>
            </div>

            <h1 className="text-xl sm:text-2xl font-bold leading-snug text-balance">
              مرور گام‌به‌گام درسنامه‌ها و تست‌های شناسنامه‌دار کنکور با پاسخ تشریحی کامل
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 leading-7">
              پس از پاسخ به هر تست، توضیح کامل مستخرج از کتب مرجع، دام طراح سازمان سنجش و خلاصه درسنامه همان مبحث نمایش داده می‌شود و تسلط شما در درخت دانش به‌روز می‌گردد.
            </p>

            {/* خلاصه ترکیب صف امروز */}
            <div className="grid grid-cols-3 gap-3 pt-1">
              <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                <div className="text-[11px] text-slate-400">تست‌های کنکور</div>
                <div className="text-base font-bold mt-0.5 tabular-nums">
                  {queue.filter((c) => c.cardType === 'question').length} تست
                </div>
              </div>
              <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                <div className="text-[11px] text-slate-400">تست اثبات ۱۴۰۴</div>
                <div className="text-base font-bold text-amber-400 mt-0.5 tabular-nums">
                  {queue.filter((c) => c.cardType === 'proof_1404').length} آزمون
                </div>
              </div>
              <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                <div className="text-[11px] text-slate-400">درسنامه و پیش‌نیاز</div>
                <div className="text-base font-bold text-emerald-400 mt-0.5 tabular-nums">
                  {probeOrRemedialCards.length} کارت
                </div>
              </div>
            </div>
          </div>

          <div className="pt-6 mt-6 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => {
                tmaHaptic.impact('heavy');
                onStartDailySession();
              }}
              className="min-h-[44px] px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>شروع مرور امروز ({queue.length} گام)</span>
            </button>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  tmaHaptic.impact('light');
                  onOpenPlacementModal();
                }}
                className="min-h-[40px] px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Compass className="w-3.5 h-3.5 text-blue-400" />
                <span>تعیین سطح (۵ سؤال)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  tmaHaptic.impact('medium');
                  onStartNightQuiz();
                }}
                className="min-h-[40px] px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Moon className="w-3.5 h-3.5 text-amber-300" />
                <span>کوییز شبانه</span>
              </button>
            </div>
          </div>
        </div>

        {/* کارت وضعیت تسلط و مأموریت‌های روزانه */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800/80 rounded-2xl p-6 flex flex-col justify-between">
          <div className="flex items-center justify-between gap-4 pb-3 border-b border-slate-200/70 dark:border-slate-800">
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                تسلط کل گراف دانش و مأموریت‌های امروز
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 tabular-nums">
                تراز خالص با نمره منفی: {netKonkorPercent}٪
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigateTab('map')}
              className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
            >
              مشاهده درخت مهارت ←
            </button>
          </div>

          <div className="flex items-center gap-5 my-4">
            <div className="relative w-22 h-22 shrink-0 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 104 104">
                <circle
                  cx="52"
                  cy="52"
                  r={ringRadius}
                  fill="none"
                  strokeWidth="8"
                  className="stroke-slate-200 dark:stroke-slate-800"
                />
                <circle
                  cx="52"
                  cy="52"
                  r={ringRadius}
                  fill="none"
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={ringCircumference}
                  strokeDashoffset={ringOffset}
                  className="stroke-blue-600 dark:stroke-blue-400 transition-all duration-500"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                <span className="text-base font-bold text-slate-900 dark:text-white tabular-nums">
                  {overallMastery}٪
                </span>
                <span className="text-[10px] text-slate-500 dark:text-slate-400">تسلط کل</span>
              </div>
            </div>

            <div className="space-y-1.5 flex-1 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-400">مباحث تثبیت‌شده:</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                  {masteredOrProvenCount} از {nodes.length}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-400">درسنامه‌های خوانده‌شده:</span>
                <span className="font-bold text-blue-600 dark:text-blue-400 tabular-nums">
                  {stats.lessonsRatedCount} مبحث
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-400">صحیح / غلط / نزده:</span>
                <span className="font-mono font-bold text-slate-900 dark:text-white tabular-nums">
                  {stats.correctCount} / {stats.wrongCount} / {stats.skippedCount}
                </span>
              </div>
              {leechNodesCount > 0 && (
                <div className="flex items-center justify-between text-rose-600 dark:text-rose-400 font-bold">
                  <span className="flex items-center gap-1">
                    <AlertOctagon className="w-3.5 h-3.5" />
                    کارت‌های چغر:
                  </span>
                  <span>{leechNodesCount} مبحث</span>
                </div>
              )}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-200/70 dark:border-slate-800 space-y-1.5">
            {stats.dailyQuests.map((q) => (
              <div
                key={q.id}
                className="py-1.5 px-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between gap-2 text-xs"
              >
                <div className="flex items-center gap-2 min-w-0">
                  <CheckCircle2
                    className={`w-3.5 h-3.5 shrink-0 ${
                      q.completed ? 'text-emerald-500' : 'text-slate-300 dark:text-slate-600'
                    }`}
                  />
                  <span
                    className={`truncate ${
                      q.completed
                        ? 'line-through text-slate-400 dark:text-slate-500'
                        : 'text-slate-800 dark:text-slate-200'
                    }`}
                  >
                    {q.title}
                  </span>
                </div>
                <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400 shrink-0 tabular-nums">
                  {q.current}/{q.target}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ۳. دسترسی سریع به ۱۵ دوره کنکور سراسری مدیریت (۱۳۹۱ تا ۱۴۰۵ — دفترچه اصلی + ترتیب شماره سؤال + پاسخ تشریحی) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800/80 rounded-2xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                شبیه‌ساز کنکورهای سالانه مدیریت (۱۳۹۱ تا ۱۴۰۵ — کد ۱۱۴۲)
              </h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              روی هر سال کلیک کنید تا مستقیماً وارد آزمون همان سال به ترتیب شماره دفترچه، فایل PDF اصلی سازمان سنجش و پاسخنامه تشریحی شوید:
            </p>
          </div>

          <button
            type="button"
            onClick={() => onOpenYearlyExam(1405)}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
          >
            <span>مشاهده همه ۱۵ دوره کنکور</span>
            <ArrowLeft className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-8 gap-2">
          {YEARLY_KONKOR_BOOKLETS.map((b) => (
            <button
              key={b.year}
              type="button"
              onClick={() => {
                tmaHaptic.selection();
                onOpenYearlyExam(b.year);
              }}
              className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-blue-600 hover:text-white border border-slate-200/80 dark:border-slate-800 hover:border-blue-500 text-right transition-colors cursor-pointer group"
            >
              <div className="flex items-center justify-between gap-1">
                <span className="text-xs font-bold tabular-nums">کنکور {b.year}</span>
                <span className="text-[10px] font-mono text-slate-400 group-hover:text-blue-100">
                  {b.bookletCode}
                </span>
              </div>
              <div className="text-[10px] text-slate-500 dark:text-slate-400 group-hover:text-blue-100 mt-0.5 tabular-nums">
                {b.totalQuestionsInBooklet} سؤال · PDF
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* ۴. اولویت‌های مطالعه امروز (ROI) و فصول پرتکرار چندساله کنکور */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* ستون راست: بالاترین بازده زمانی (ROI Planner) (۵ ستون) */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800/80 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-200/70 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                اولویت‌های پیشنهادی امروز شما (بر اساس ضریب گرایش)
              </h3>
            </div>
            <button
              type="button"
              onClick={() => onNavigateTab('lessons')}
              className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
            >
              همه درسنامه‌ها
            </button>
          </div>

          <div className="space-y-2.5">
            {roiRankings.slice(0, 5).map((item, idx) => (
              <div
                key={item.node.id}
                className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/45 border border-slate-200/70 dark:border-slate-800 flex items-center justify-between gap-3"
              >
                <div className="min-w-0">
                  <div className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    {idx + 1}. {item.node.topic}
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate tabular-nums">
                    {item.node.course} · تسلط: {item.state.masteryScore}٪ · {item.examFrequencyInsight.appearanceCount} دوره کنکور
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => onOpenLessonNode(item.node.id)}
                    className="px-2.5 py-1.5 rounded-lg bg-slate-200/70 dark:bg-slate-700/70 hover:bg-blue-600 text-slate-700 dark:text-slate-200 hover:text-white text-[11px] font-bold transition-colors cursor-pointer"
                  >
                    درسنامه
                  </button>
                  <button
                    type="button"
                    onClick={() => onStartPracticeNode(item.node.id, 'practice')}
                    className="px-2.5 py-1.5 rounded-lg bg-blue-600/10 hover:bg-blue-600 text-blue-600 hover:text-white dark:text-blue-400 text-[11px] font-bold transition-colors cursor-pointer"
                  >
                    تست
                  </button>
                </div>
              </div>
            ))}
          </div>

          {needsProofNodes.length > 0 && (
            <div className="pt-3 border-t border-slate-200/70 dark:border-slate-800 space-y-2">
              <div className="text-xs font-bold text-amber-600 dark:text-amber-400 flex items-center gap-1.5">
                <Award className="w-4 h-4" />
                <span>آماده اثبات نهایی تسلط (سؤالات قرنطینه کنکور ۱۴۰۴):</span>
              </div>
              {needsProofNodes.map((n) => (
                <div
                  key={n.id}
                  className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/25 flex items-center justify-between gap-2 text-xs"
                >
                  <span className="font-bold text-slate-900 dark:text-amber-100 truncate">
                    {n.topic}
                  </span>
                  <button
                    type="button"
                    onClick={() => onStartPracticeNode(n.id, 'proof')}
                    className="px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold shrink-0 cursor-pointer"
                  >
                    شروع آزمون اثبات
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ستون چپ: رادار فصول پرتکرار ادوار کنکور (۷ ستون) */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800/80 rounded-2xl p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200/70 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-amber-500" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                فصول پرتکرار ادوار کنکور سراسری (مستند به کتب مرجع)
              </h3>
            </div>

            <div className="flex flex-wrap gap-1">
              {(['common', 'business', 'industrial', 'technology'] as TrackId[]).map((t) => {
                const isActive = stats.activeTracks.includes(t);
                return (
                  <button
                    key={t}
                    type="button"
                    onClick={() => onToggleTrack(t)}
                    className={`px-2 py-1 rounded-lg text-[11px] font-medium transition-colors cursor-pointer ${
                      isActive
                        ? 'bg-blue-600/10 text-blue-700 dark:text-blue-300 font-bold'
                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                    }`}
                  >
                    {TRACK_LABELS[t].title.replace('گرایش ', '')}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {topMultiYearNodes.map((freq) => {
              const node = nodes.find((n) => n.id === freq.nodeId);
              const state = nodeStates[freq.nodeId];
              if (!node) return null;

              return (
                <div
                  key={freq.nodeId}
                  className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/45 border border-slate-200/70 dark:border-slate-800 flex flex-col justify-between gap-3"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between gap-2 text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
                      <span className="text-amber-600 dark:text-amber-400 font-bold">
                        {freq.appearanceCount} دوره کنکور ({freq.yearsAppeared.slice(-4).join('، ')})
                      </span>
                      <span>تسلط: {state?.masteryScore ?? 0}٪</span>
                    </div>

                    <h4 className="text-xs font-bold text-slate-900 dark:text-white leading-6">
                      {node.course} — {node.topic}
                    </h4>

                    <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 leading-5">
                      منبع: {freq.sourceBookCitation}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between gap-2 text-xs">
                    <button
                      type="button"
                      onClick={() => onOpenLessonNode(node.id)}
                      className="font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>مطالعه درسنامه</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onStartPracticeNode(node.id, 'practice')}
                      className="px-2.5 py-1 rounded-lg bg-slate-900 dark:bg-slate-700 hover:bg-blue-600 text-white text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <Play className="w-3 h-3" />
                      <span>حل تست</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
